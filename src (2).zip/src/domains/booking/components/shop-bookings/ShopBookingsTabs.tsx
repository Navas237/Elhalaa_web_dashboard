'use client'

import { memo } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Tabs, TabsList, TabsTrigger } from '@/shared/components/ui/tabs'
import { ShopBookingsToolbar, type BookingsTabValue } from './ShopBookingsToolbar'
import { ShopBookingsList } from './ShopBookingsList'
import { useShopBookings } from '../../hooks/useShopBookings'
import type { ShopStaffMemberDto } from '@/domains/staff/dto/staff.dto'

export interface ShopBookingsTabsProps {
  shopId: string
  staff: ShopStaffMemberDto[]
  staffLoading: boolean
  activeTab: BookingsTabValue
  barberId: string | null
  dateFrom: string | null
  dateTo: string | null
  onTabChange: (tab: BookingsTabValue) => void
  onBarberChange: (barberId: string | null) => void
  onDateFromChange: (date: string | null) => void
  onDateToChange: (date: string | null) => void
}

const tabLabels: Record<BookingsTabValue, string> = {
  upcoming: 'القادمة',
  waiting: 'في الانتظار',
  past: 'السابقة',
}

// خريطة كل تبويب إلى قائمة الحالات المفصولة بفاصلة (يدعمها الـRPC بعد B2)
const tabStatusFilter: Record<BookingsTabValue, string> = {
  upcoming: 'pending,confirmed',
  waiting: 'waiting_time',
  past: 'completed,cancelled,no_show',
}

function ShopBookingsTabsImpl({
  shopId,
  staff,
  staffLoading,
  activeTab,
  barberId,
  dateFrom,
  dateTo,
  onTabChange,
  onBarberChange,
  onDateFromChange,
  onDateToChange,
}: ShopBookingsTabsProps) {
  const statusFilter = tabStatusFilter[activeTab]
  const { bookings, loading, error, refetch } = useShopBookings(shopId, {
    statusFilter,
    barberId: barberId ?? undefined,
    dateFrom: dateFrom ?? undefined,
    dateTo: dateTo ?? undefined,
  })

  return (
    <div className="flex flex-col gap-3" dir="rtl">
      <Tabs
        value={activeTab}
        onValueChange={(v) => onTabChange(v as BookingsTabValue)}
      >
        <TabsList className="w-full">
          {(Object.keys(tabLabels) as BookingsTabValue[]).map((tab) => (
            <TabsTrigger key={tab} value={tab} className="flex-1">
              {tabLabels[tab]}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      <ShopBookingsToolbar
        staff={staff}
        staffLoading={staffLoading}
        activeTab={activeTab}
        barberId={barberId}
        dateFrom={dateFrom}
        dateTo={dateTo}
        onBarberChange={onBarberChange}
        onDateFromChange={onDateFromChange}
        onDateToChange={onDateToChange}
      />

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
        >
          <ShopBookingsList
            bookings={bookings}
            loading={loading}
            error={error}
            onRetry={() => refetch()}
          />
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

export const ShopBookingsTabs = memo(ShopBookingsTabsImpl)