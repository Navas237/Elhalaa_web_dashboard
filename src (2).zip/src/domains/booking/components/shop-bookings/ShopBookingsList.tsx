'use client'

import { memo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { CalendarX2, AlertCircle, RefreshCcw } from 'lucide-react'
import { Button } from '@/shared/components/ui/button'
import { ShopBookingCard } from './ShopBookingCard'
import { ShopBookingCardSkeleton } from './ShopBookingCardSkeleton'
import type { ShopBookingCardDto } from '../../dto/shop-booking.dto'
import { BookingActionsSheet } from '../BookingActionsSheet'

interface ShopBookingsListProps {
  bookings: ShopBookingCardDto[]
  loading: boolean
  error: string | null
  onRetry: () => void
}

const itemVariants = {
  hidden: { opacity: 0, y: 14 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.25 } },
}

function ShopBookingsListImpl({
  bookings,
  loading,
  error,
  onRetry,
}: ShopBookingsListProps) {
  const [selectedBooking, setSelectedBooking] = useState<ShopBookingCardDto | null>(null)

  if (error) {
    return (
      <div
        className="flex flex-col items-center justify-center py-12 text-center"
        dir="rtl"
      >
        <div className="bg-destructive/10 p-3 rounded-full mb-3">
          <AlertCircle className="h-6 w-6 text-destructive" />
        </div>
        <p className="font-medium text-destructive text-sm mb-3">{error}</p>
        <Button variant="outline" size="sm" className="gap-1.5" onClick={onRetry}>
          <RefreshCcw className="h-4 w-4" />
          إعادة المحاولة
        </Button>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex flex-col gap-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <ShopBookingCardSkeleton key={i} />
        ))}
      </div>
    )
  }

  if (bookings.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center py-12 text-center"
        dir="rtl"
      >
        <div className="bg-muted p-4 rounded-full mb-3">
          <CalendarX2 className="h-7 w-7 text-muted-foreground" />
        </div>
        <p className="text-sm text-muted-foreground">لا توجد حجوزات</p>
      </div>
    )
  }

  return (
    <>
      <motion.div
        initial="hidden"
        animate="visible"
        variants={{ visible: { transition: { staggerChildren: 0.06 } } }}
        className="flex flex-col gap-3"
      >
        <AnimatePresence mode="popLayout">
          {bookings.map((booking) => (
            <motion.div key={booking.id} variants={itemVariants} layout onClick={() => setSelectedBooking(booking)} className="cursor-pointer">
              <ShopBookingCard booking={booking} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      <BookingActionsSheet
        isOpen={!!selectedBooking}
        onClose={() => setSelectedBooking(null)}
        booking={selectedBooking}
      />
    </>
  )
}

export const ShopBookingsList = memo(ShopBookingsListImpl)