'use client'

import { useState, useMemo } from 'react'
import { Search, Plus } from 'lucide-react'
import { Input } from '@/shared/components/ui/input'
import { Skeleton } from '@/shared/components/ui/skeleton'
import { Button } from '@/shared/components/ui/button'
import { AnimatePresence } from 'framer-motion'
import { useOwnerBookings, useOwnerBookingCounts } from '../../hooks/use-owner-bookings'
import { useBookingsFilter } from '../../hooks/use-bookings-filter'
import { BookingCard } from './BookingCard'
import { BookingsFilter } from './BookingsFilter'
import { BookingDetailsModal } from './BookingDetailsModal'
import { NewBookingSheet } from '../wizard/NewBookingSheet'
import type { BookingCardDto } from '../../dto/booking.dto'

export function BookingsList({ ownerId }: { ownerId: string }) {
  const [page, setPage] = useState(1)
  const pageSize = 50
  
  const [searchQuery, setSearchQuery] = useState('')
  const [filters, setFilters] = useState<any>({
    status: 'all',
    shopName: null,
    barberName: null,
    date: null
  })

  const { data: bookings, isLoading, isFetching } = useOwnerBookings(ownerId, page, pageSize, filters.status)
  const { data: countsData } = useOwnerBookingCounts(ownerId)
  
  const {
    uniqueShops, uniqueBarbers,
    filteredBookings, counts
  } = useBookingsFilter(bookings, countsData, filters, searchQuery)

  const [selectedBooking, setSelectedBooking] = useState<BookingCardDto | null>(null)
  const [isNewBookingOpen, setIsNewBookingOpen] = useState(false)

  // Reset page when filters change
  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters)
    setPage(1)
  }

  const totalCount = bookings?.[0]?.totalCount || 0
  const totalPages = Math.ceil(totalCount / pageSize)

  return (
    <div className="flex flex-col gap-4 py-4 px-4 pb-24" dir="rtl">
      <div className="space-y-4">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold">الحجوزات</h1>
            <p className="text-sm text-muted-foreground">إدارة جميع حجوزات الفروع</p>
          </div>
          <Button 
            size="icon" 
            className="rounded-full w-12 h-12 shadow-sm"
            onClick={() => setIsNewBookingOpen(true)}
          >
            <Plus className="w-6 h-6" />
          </Button>
        </div>
        
        <div className="relative shadow-sm rounded-full">
          <Input 
            placeholder="بحث برقم الهاتف، أو اسم العميل..." 
            className="pr-11 h-12 rounded-full bg-white dark:bg-zinc-900 border-muted focus-visible:ring-primary/20 text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="absolute right-4 top-3.5 h-5 w-5 text-muted-foreground/70" />
        </div>

        <BookingsFilter 
          filters={filters} 
          onFiltersChange={handleFilterChange} 
          counts={counts}
          uniqueShops={uniqueShops}
          uniqueBarbers={uniqueBarbers}
        />
      </div>

      <div className="flex flex-col gap-3 mt-2">
        {isLoading || isFetching ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-[120px] w-full rounded-xl bg-muted/50" />
          ))
        ) : filteredBookings.length > 0 ? (
          <AnimatePresence mode="popLayout">
            {filteredBookings.map(booking => (
              <BookingCard 
                key={booking.id} 
                booking={booking} 
                onClick={setSelectedBooking} 
              />
            ))}
          </AnimatePresence>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <p>لا توجد حجوزات تطابق بحثك أو فلاترك الحالية</p>
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex justify-between items-center mt-4">
          <Button 
            variant="outline" 
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1 || isFetching}
          >
            السابق
          </Button>
          <span className="text-sm text-muted-foreground">
            صفحة {page} من {totalPages}
          </span>
          <Button 
            variant="outline" 
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages || isFetching}
          >
            التالي
          </Button>
        </div>
      )}

      <BookingDetailsModal
        booking={selectedBooking}
        isOpen={!!selectedBooking}
        onClose={() => setSelectedBooking(null)}
      />

      <NewBookingSheet 
        open={isNewBookingOpen}
        onOpenChange={setIsNewBookingOpen}
      />
    </div>
  )
}
