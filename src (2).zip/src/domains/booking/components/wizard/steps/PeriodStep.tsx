'use client'

import { useFormContext } from 'react-hook-form'
import { Sun, Sunset, Moon, Sunrise } from 'lucide-react'
import { BookingWizardValues } from '../BookingWizard'
import { cn } from '@/lib/utils'

interface PeriodStepProps {
  onNext: () => void
}

const PERIODS = [
  { id: 'morning', label: 'الصباح', time: '6 ص - 12 م', icon: Sunrise },
  { id: 'afternoon', label: 'الظهر', time: '12 م - 3 م', icon: Sun },
  { id: 'evening', label: 'العصر', time: '3 م - 6 م', icon: Sunset },
  { id: 'night', label: 'المساء', time: '6 م - 11 م', icon: Moon },
] as const

export function PeriodStep({ onNext }: PeriodStepProps) {
  const { watch, setValue } = useFormContext<BookingWizardValues>()
  const selectedPeriod = watch('period')

  const handleSelect = (id: 'morning' | 'afternoon' | 'evening' | 'night') => {
    setValue('period', id, { shouldValidate: true })
    setValue('selectedSlot', null)
    
    setTimeout(() => {
      onNext()
    }, 150)
  }

  return (
    <div className="flex flex-col h-full pb-[90px]">
      <div className="grid grid-cols-2 gap-3">
        {PERIODS.map((period) => {
          const isSelected = selectedPeriod === period.id
          const Icon = period.icon
          
          return (
            <button
              key={period.id}
              type="button"
              onClick={() => handleSelect(period.id)}
              className={cn(
                "flex flex-col items-center gap-3 p-6 rounded-2xl border transition-all",
                isSelected 
                  ? "border-primary bg-primary/5 ring-1 ring-primary/20" 
                  : "border-slate-200 bg-white hover:border-primary/30 hover:bg-slate-50"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center mb-2",
                isSelected ? "bg-primary/10 text-primary" : "bg-slate-100 text-slate-500"
              )}>
                <Icon className="w-6 h-6" />
              </div>
              <h4 className={cn(
                "font-bold text-base",
                isSelected ? "text-primary" : "text-slate-900"
              )}>
                {period.label}
              </h4>
              <p className="text-xs text-slate-500">{period.time}</p>
            </button>
          )
        })}
      </div>
    </div>
  )
}
