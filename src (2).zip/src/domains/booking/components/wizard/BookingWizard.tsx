'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useForm, FormProvider } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/shared/components/ui/button'

import { CustomerStep } from './steps/CustomerStep'
import { BranchStep } from './steps/BranchStep'
import { ServiceStep } from './steps/ServiceStep'
import { BarberStep } from './steps/BarberStep'
import { DateStep } from './steps/DateStep'
import { PeriodStep } from './steps/PeriodStep'
import { TimeStep } from './steps/TimeStep'
import { ReviewStep } from './steps/ReviewStep'

import { bookingWizardSchema, type BookingWizardValues } from '../../schemas/wizard.schema'
export type { BookingWizardValues }

const steps = [
  { id: 'customer', title: 'بيانات العميل' },
  { id: 'branch', title: 'اختيار الفرع' },
  { id: 'service', title: 'الخدمة' },
  { id: 'barber', title: 'الحلاق' },
  { id: 'date', title: 'اليوم' },
  { id: 'period', title: 'الفترة' },
  { id: 'time', title: 'الوقت' },
  { id: 'review', title: 'المراجعة' },
]

interface BookingWizardProps {
  onClose: () => void
}

export function BookingWizard({ onClose }: BookingWizardProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [direction, setDirection] = useState(1)

  const methods = useForm<BookingWizardValues>({
    resolver: zodResolver(bookingWizardSchema),
    defaultValues: {
      clientName: '',
      clientPhone: '',
      shopId: '',
      serviceId: '',
      staffId: '',
      targetDate: '',
      period: 'morning',
      selectedSlot: null,
    },
    mode: 'onChange',
  })

  const goToNextStep = () => {
    if (currentStep < steps.length - 1) {
      setDirection(1)
      setCurrentStep(s => s + 1)
    }
  }

  const goToPrevStep = () => {
    if (currentStep > 0) {
      setDirection(-1)
      setCurrentStep(s => s - 1)
    }
  }

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 50 : -50,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 50 : -50,
      opacity: 0
    })
  }

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return <CustomerStep onNext={goToNextStep} />
      case 1:
        return <BranchStep onNext={goToNextStep} />
      case 2:
        return <ServiceStep onNext={goToNextStep} />
      case 3:
        return <BarberStep onNext={goToNextStep} />
      case 4:
        return <DateStep onNext={goToNextStep} />
      case 5:
        return <PeriodStep onNext={goToNextStep} />
      case 6:
        return <TimeStep onNext={goToNextStep} onBack={goToPrevStep} />
      case 7:
        return <ReviewStep onClose={onClose} />
      default:
        return null
    }
  }

  const progress = ((currentStep + 1) / steps.length) * 100

  return (
    <div className="flex flex-col h-full bg-slate-50/50">
      {/* Progress & Header */}
      <div className="px-6 pb-2">
        <div className="flex items-center gap-3 mb-4">
          {currentStep > 0 && (
            <Button
              type="button"
              variant="ghost"
              size="icon-sm"
              onClick={goToPrevStep}
              className="rounded-full shrink-0"
            >
              <ArrowRight className="h-5 w-5" />
            </Button>
          )}
          <div className="flex-1">
            <h3 className="text-sm font-bold text-slate-700">{steps[currentStep].title}</h3>
            <p className="text-xs text-slate-500 font-medium">الخطوة {currentStep + 1} من {steps.length}</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
        </div>
      </div>

      {/* Step Content with Framer Motion */}
      <FormProvider {...methods}>
        <div className="flex-1 overflow-x-hidden overflow-y-auto no-scrollbar relative">
          <AnimatePresence initial={false} custom={direction} mode="wait">
            <motion.div
              key={currentStep}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
              className="absolute inset-0 px-6 py-4"
            >
              {renderStep()}
            </motion.div>
          </AnimatePresence>
        </div>
      </FormProvider>
    </div>
  )
}
