import { useMutation, useQueryClient } from '@tanstack/react-query'
import { updateBookingStatus } from '../services/booking.service'
import { bookingKeys } from '../query-keys'
import type { BookingStatus } from '@/shared/types/database'

export function useUpdateBookingStatus(shopId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ bookingId, status }: { bookingId: string; status: BookingStatus }) =>
      updateBookingStatus(bookingId, status),
    onSuccess: () => {
      // Invalidate the shop's bookings list to reflect the new status
      queryClient.invalidateQueries({ queryKey: bookingKeys.shop(shopId) })
    },
  })
}
