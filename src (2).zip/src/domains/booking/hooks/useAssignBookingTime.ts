import { useMutation, useQueryClient } from '@tanstack/react-query'
import { assignBookingTime } from '../services/booking.service'
import { bookingKeys } from '../query-keys'

interface AssignBookingTimeParams {
  bookingId: string
  params: {
    booking_date: string
    start_time: string
    end_time: string
    display_start_time: string
  }
}

export function useAssignBookingTime(shopId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ bookingId, params }: AssignBookingTimeParams) =>
      assignBookingTime(bookingId, params),
    onSuccess: () => {
      // Invalidate the shop's bookings list to reflect the new time and status
      queryClient.invalidateQueries({ queryKey: bookingKeys.shop(shopId) })
    },
  })
}
