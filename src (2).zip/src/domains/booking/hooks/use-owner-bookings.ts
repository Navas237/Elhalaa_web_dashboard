import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getOwnerBookings, updateBookingStatus, getOwnerBookingCounts } from '../services/booking.service'
import { bookingKeys } from '../query-keys'
import type { BookingStatus } from '@/shared/types/database'

export function useOwnerBookings(ownerId: string | undefined, page?: number, pageSize?: number, statusFilter?: string) {
  return useQuery({
    queryKey: [...bookingKeys.list(ownerId!), page, pageSize, statusFilter],
    queryFn: () => getOwnerBookings(ownerId!, page, pageSize, statusFilter),
    enabled: !!ownerId,
  })
}

export function useOwnerBookingCounts(ownerId: string | undefined) {
  return useQuery({
    queryKey: [...bookingKeys.all, 'counts', ownerId],
    queryFn: () => getOwnerBookingCounts(ownerId!),
    enabled: !!ownerId,
    refetchInterval: 30000 // Refetch counts every 30s as a fallback, though mutations invalidate bookingKeys.all
  })
}

export function useUpdateBookingStatus(ownerId: string | undefined) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ bookingId, newStatus }: { bookingId: string; newStatus: BookingStatus }) =>
      updateBookingStatus(bookingId, newStatus),
    onSuccess: () => {
      if (ownerId) {
        queryClient.invalidateQueries({ queryKey: bookingKeys.all })
      }
    },
  })    
}
