import type { BookingStatus } from "@/shared/types/database"
import type { OwnerBookingRpc } from "../typys/booking.types" 

export interface BookingCardDto {
  id: string
  customerName: string
  customerPhone: string | null
  barberName: string
  serviceName: string
  shopName: string
  displayStartTime: string
  bookingDate: string
  servicePrice: number
  serviceDuration: number
  notes: string | null
  status: BookingStatus
  totalCount?: number
}

export function toBookingCardDto(
  booking: OwnerBookingRpc
): BookingCardDto {
  return {
    id: booking.id,
    customerName: booking.client_name,
    customerPhone: booking.client_phone,
    barberName: booking.barber_name,
    serviceName: booking.service_name,
    shopName: booking.shop_name,
    displayStartTime: booking.display_start_time,
    bookingDate: booking.date_of_booking,
    servicePrice: booking.service_price,
    serviceDuration: booking.service_duration,
    notes: booking.notes,
    status: booking.status,
    totalCount: booking.total_count,
  }
}