import { BookingsList } from '@/domains/booking/components/owner-bookings/BookingsList'
import { createClient } from '@/shared/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function OwnerBookingsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  return <BookingsList ownerId={user.id} />
}
