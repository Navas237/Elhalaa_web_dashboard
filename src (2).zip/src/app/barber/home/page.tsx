"use client"
import { useAuth } from "@/domains/auth/hooks/useAuth"

export default function BarberHomePage() {

const { logout} = useAuth()


  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">الرئيسية (الحلاق)</h1>
      <p className="mt-2 text-slate-600">أهلاً بك في لوحة تحكم الحلاق.</p>
      <button onClick={logout}>Logout</button>
    </div>
  )
}
