"use client";

import {QueryClient , QueryClientProvider} from "@tanstack/react-query"; 
import { useState } from "react";
// import { Toaster } from "@/shared/components/ui/sonner";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";

export default function Providers({children} : {children : React.ReactNode}){

    const [queryClient] = useState(()=> new QueryClient({
        defaultOptions : {
            queries : {
                 staleTime : 1000 * 60 ,
                 gcTime : 1000*60*10 ,
                 refetchOnWindowFocus : false ,
                 retry : 1 
            }
        }
    }));

    return (
        <QueryClientProvider client={queryClient}>
            {children}
            <ReactQueryDevtools initialIsOpen={false} />
            {/* <Toaster /> */}
        </QueryClientProvider>
    )
}